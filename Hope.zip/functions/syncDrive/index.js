
/**
 * functions/syncDrive/index.js
 * New Drive Sync function: writes photos into batched schema:
 * photos/{userId} (doc) with subcollection 'batches' containing batch-001, batch-002...
 *
 * Requirements implemented:
 * - Uses Google Drive v3 API via googleapis
 * - Traverses root folder: immediate subfolders => albums
 * - For each album, collects images from folder and all descendants
 * - Sorts images by captureTime ascending
 * - Creates/auto-creates photos/{userId} doc if missing and writes album list
 * - Writes batches of up to 800 photo objects to photos/{userId}/batches/{batchId}
 * - Ensures Drive files have 'anyoneWithLink' permission (creates permission if necessary)
 *
 * Note: This function requires the Cloud Functions runtime to have Google API credentials available
 * via Application Default Credentials (service account). Ensure the service account has Drive API access.
 */

const {google} = require('googleapis');
const admin = require('firebase-admin');

if (!admin.apps.length) admin.initializeApp();

const db = admin.firestore();

const BATCH_SIZE = 800;

const authScopes = ['https://www.googleapis.com/auth/drive'];

async function getDriveClient() {
  const auth = new google.auth.GoogleAuth({
    scopes: authScopes,
  });
  const authClient = await auth.getClient();
  return google.drive({version: 'v3', auth: authClient});
}

async function listFolderChildren(drive, folderId) {
  const items = [];
  let pageToken = null;
  do {
    const res = await drive.files.list({
      q: `'${folderId}' in parents and trashed=false`,
      fields: 'nextPageToken, files(id, name, mimeType, createdTime)',
      pageToken: pageToken || undefined,
      spaces: 'drive',
      pageSize: 1000,
    });
    if (res.data.files) items.push(...res.data.files);
    pageToken = res.data.nextPageToken;
  } while (pageToken);
  return items;
}

async function listFilesRecursive(drive, folderId) {
  // BFS through folders beginning at folderId, collect image files
  const images = [];
  const queue = [folderId];
  while (queue.length) {
    const current = queue.shift();
    const items = await listFolderChildren(drive, current);
    for (const it of items) {
      if (it.mimeType === 'application/vnd.google-apps.folder') {
        queue.push(it.id);
      } else if (it.mimeType && it.mimeType.startsWith('image/')) {
        images.push(it);
      }
    }
  }
  return images;
}

function buildImageUrls(fileId) {
  // public URLs using lh3 pattern / drive download link
  return {
    thumb_1000: `https://lh3.googleusercontent.com/d/${fileId}=s1000`,
    full_4000: `https://lh3.googleusercontent.com/d/${fileId}=s4000`,
    zoom_8000: `https://lh3.googleusercontent.com/d/${fileId}=s8000`,
    download_url: `https://drive.google.com/uc?export=download&id=${fileId}`,
  };
}

async function ensureAnyoneWithLink(drive, fileId) {
  try {
    // Check existing permissions
    const perms = await drive.permissions.list({fileId, fields: 'permissions(id,type,role)'});
    const exists = (perms.data.permissions || []).some(p => p.type === 'anyone');
    if (!exists) {
      await drive.permissions.create({
        fileId,
        requestBody: {
          role: 'reader',
          type: 'anyone',
        },
      });
    }
  } catch (err) {
    console.warn('ensureAnyoneWithLink failed for', fileId, err.message || err);
    // not fatal
  }
}

function safeCaptureTime(fileMeta) {
  // Prefer imageMediaMetadata.time if present, else createdTime
  if (fileMeta && fileMeta.imageMediaMetadata && fileMeta.imageMediaMetadata.time) {
    return fileMeta.imageMediaMetadata.time;
  }
  return fileMeta.createdTime || null;
}

exports.syncDriveBatches = async (userId, rootFolderId) => {
  if (!userId || !rootFolderId) throw new Error('userId and rootFolderId required');

  const drive = await getDriveClient();

  // Get root folder metadata (name)
  let rootName = 'Drive Uploads';
  try {
    const rmeta = await drive.files.get({fileId: rootFolderId, fields: 'id,name'});
    if (rmeta && rmeta.data && rmeta.data.name) rootName = rmeta.data.name;
  } catch (e) {
    console.warn('Could not read root folder metadata', e.message || e);
  }

  // List immediate subfolders => these are albums
  const children = await listFolderChildren(drive, rootFolderId);
  const albumFolders = children.filter(c => c.mimeType === 'application/vnd.google-apps.folder');

  const allPhotos = []; // collect all photos across albums (each photo has album field)

  for (const album of albumFolders) {
    const albumName = album.name || 'Untitled Album';
    // Recursively collect image files under this album folder
    const imageFiles = await listFilesRecursive(drive, album.id);

    // For each image file, get detailed metadata including imageMediaMetadata
    for (const f of imageFiles) {
      try {
        const metaRes = await drive.files.get({
          fileId: f.id,
          fields: 'id,name,mimeType,createdTime,imageMediaMetadata,thumbnailLink',
        });
        const fm = metaRes.data || {};
        const captureTime = safeCaptureTime(fm);
        // Ensure link permission
        await ensureAnyoneWithLink(drive, fm.id);

        const urls = buildImageUrls(fm.id);
        allPhotos.push({
          id: fm.id,
          name: fm.name || '',
          mimeType: fm.mimeType || '',
          thumb_1000: urls.thumb_1000,
          full_4000: urls.full_4000,
          zoom_8000: urls.zoom_8000,
          download_url: urls.download_url,
          captureTime: captureTime,
          album: albumName,
        });
      } catch (err) {
        console.warn('failed to get file meta for', f.id, err.message || err);
      }
    } // end for imageFiles
  } // end for albumFolders

  // If no album folders found, also try files directly under root as single album
  if (albumFolders.length === 0) {
    const imageFiles = await listFilesRecursive(drive, rootFolderId);
    for (const f of imageFiles) {
      try {
        const metaRes = await drive.files.get({
          fileId: f.id,
          fields: 'id,name,mimeType,createdTime,imageMediaMetadata,thumbnailLink',
        });
        const fm = metaRes.data || {};
        const captureTime = safeCaptureTime(fm);
        await ensureAnyoneWithLink(drive, fm.id);
        const urls = buildImageUrls(fm.id);
        allPhotos.push({
          id: fm.id,
          name: fm.name || '',
          mimeType: fm.mimeType || '',
          thumb_1000: urls.thumb_1000,
          full_4000: urls.full_4000,
          zoom_8000: urls.zoom_8000,
          download_url: urls.download_url,
          captureTime: captureTime,
          album: rootName,
        });
      } catch (err) {
        console.warn('failed to get file meta for', f.id, err.message || err);
      }
    }
  }

  // Sort allPhotos by captureTime ascending (nulls go last)
  allPhotos.sort((a,b)=>{
    const ta = a.captureTime ? new Date(a.captureTime).getTime() : Number.MAX_SAFE_INTEGER;
    const tb = b.captureTime ? new Date(b.captureTime).getTime() : Number.MAX_SAFE_INTEGER;
    return ta - tb;
  });

  // Prepare Firestore writes: ensure root doc exists
  const userDocRef = db.collection('photos').doc(userId);
  try {
    await userDocRef.set({
      albumName: rootName,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      photoCount: allPhotos.length,
    }, {merge:true});
  } catch (e) {
    console.error('failed to create/update root photos doc', e.message || e);
  }

  // split into batches of BATCH_SIZE
  let batchIndex = 1;
  let writeCount = 0;
  for (let i=0;i<allPhotos.length;i+=BATCH_SIZE) {
    const slice = allPhotos.slice(i, i+BATCH_SIZE);
    const batchId = `batch-${String(batchIndex).padStart(3,'0')}`;
    const batchDocRef = userDocRef.collection('batches').doc(batchId);
    try {
      await batchDocRef.set({
        photos: slice,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        count: slice.length,
        batchIndex,
      });
      writeCount += slice.length;
    } catch (err) {
      console.error('failed to write batch', batchId, err.message || err);
    }
    batchIndex++;
  }

  // Log activity
  try {
    await db.collection('activity_logs').add({
      action: 'sync_drive_batches',
      userId,
      folderId: rootFolderId,
      photosFound: allPhotos.length,
      written: writeCount,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  } catch (e) {
    console.warn('failed to write activity log', e.message || e);
  }

  return {status:'success', photosFound: allPhotos.length, written: writeCount};
};
