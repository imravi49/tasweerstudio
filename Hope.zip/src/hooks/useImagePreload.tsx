import { useEffect, useRef } from 'react';

interface PreloadOptions {
  range?: number;
  maxRetries?: number;
}

/**
 * useImagePreload
 * - Accepts either: urls: string[] (legacy) OR photos: Array<{thumb_1000, full_4000, zoom_8000}>
 * - Preloads in progressive order for each image: thumb_1000 -> full_4000 -> zoom_8000
 * - Preloads images within `range` of currentIndex (both directions)
 * - Non-blocking; caches loaded URLs
 */
export const useImagePreload = (
  items: any[], // urls[] OR photo objects
  currentIndex: number,
  options: PreloadOptions = {}
) => {
  const { range = 5, maxRetries = 3 } = options;
  const loadedImages = useRef<Set<string>>(new Set());
  const retryCount = useRef<Map<string, number>>(new Map());

  const toUrls = (item: any) => {
    if (!item) return {thumb:null, full:null, zoom:null};
    if (typeof item === 'string') return { thumb: item, full: item, zoom: item };
    return {
      thumb: item.thumb_1000 || item.thumbnail || item.thumb_url || null,
      full: item.full_4000 || item.full_url || item.url || null,
      zoom: item.zoom_8000 || item.zoom_url || null,
    };
  };

  useEffect(() => {
    const loaded = loadedImages.current;
    const retries = retryCount.current;

    const preloadImage = (src: string) => {
      if (!src) return Promise.resolve();
      if (loaded.has(src)) return Promise.resolve();
      return new Promise<void>((resolve) => {
        const img = new Image();
        img.onload = () => {
          loaded.add(src);
          retries.delete(src);
          resolve();
        };
        img.onerror = () => {
          const c = retries.get(src) || 0;
          if (c < maxRetries) {
            retries.set(src, c + 1);
            setTimeout(() => preloadImage(src).then(resolve), 300 * (c + 1));
          } else {
            retries.delete(src);
            resolve();
          }
        };
        img.src = src;
      });
    };

    const preloadRange = async () => {
      if (!items || items.length === 0) return;
      const start = Math.max(0, currentIndex - range);
      const end = Math.min(items.length - 1, currentIndex + range);
      const toPreload: string[] = [];

      // For each item in window, push thumb first, then full for near items, then zoom for current.
      for (let i = start; i <= end; i++) {
        const { thumb, full, zoom } = toUrls(items[i]);
        if (thumb) toPreload.push(thumb);
        // if within 2 indices of current, also preload full
        if (Math.abs(i - currentIndex) <= 2 && full) toPreload.push(full);
      }
      // ensure current image's zoom is preloaded last (non-blocking)
      const cur = toUrls(items[currentIndex]);
      if (cur.zoom) toPreload.push(cur.zoom);

      // Deduplicate while preserving order
      const seen = new Set();
      const ordered = toPreload.filter(s => {
        if (!s) return false;
        if (seen.has(s)) return false;
        seen.add(s);
        return true;
      });

      // Fire off non-blocking preload promises, but await to limit memory spikes
      const concurrency = 6;
      for (let i = 0; i < ordered.length; i += concurrency) {
        const slice = ordered.slice(i, i + concurrency);
        await Promise.all(slice.map(src => preloadImage(src)));
      }
    };

    preloadRange().catch((e)=>console.warn('preload error', e));
  }, [items, currentIndex, range, maxRetries]);

  return {
    isLoaded: (urlOrItem: string|any) => {
      const src = typeof urlOrItem === 'string' ? urlOrItem : (toUrls(urlOrItem).full || toUrls(urlOrItem).thumb);
      return loadedImages.current.has(src);
    },
    clearCache: () => {
      loadedImages.current.clear();
      retryCount.current.clear();
    },
  };
};
